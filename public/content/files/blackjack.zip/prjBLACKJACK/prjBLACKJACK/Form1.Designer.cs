﻿namespace prjBLACKJACK
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnDraw = new System.Windows.Forms.Button();
            this.picCard1 = new System.Windows.Forms.PictureBox();
            this.lblValueValue = new System.Windows.Forms.Label();
            this.txtWager = new System.Windows.Forms.TextBox();
            this.lblWager = new System.Windows.Forms.Label();
            this.lblBalance = new System.Windows.Forms.Label();
            this.lblBalanceValue = new System.Windows.Forms.Label();
            this.btnStand = new System.Windows.Forms.Button();
            this.btnBet = new System.Windows.Forms.Button();
            this.picCard2 = new System.Windows.Forms.PictureBox();
            this.picCard3 = new System.Windows.Forms.PictureBox();
            this.picCard4 = new System.Windows.Forms.PictureBox();
            this.picOpponentCard1 = new System.Windows.Forms.PictureBox();
            this.picOpponentCard2 = new System.Windows.Forms.PictureBox();
            this.picOpponentCard3 = new System.Windows.Forms.PictureBox();
            this.picOpponentCard4 = new System.Windows.Forms.PictureBox();
            this.btnRestart = new System.Windows.Forms.Button();
            this.lblOpponentsValue = new System.Windows.Forms.Label();
            this.btnPLAY = new System.Windows.Forms.Button();
            this.btnExit = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.picCard1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picCard2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picCard3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picCard4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picOpponentCard1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picOpponentCard2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picOpponentCard3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picOpponentCard4)).BeginInit();
            this.SuspendLayout();
            // 
            // btnDraw
            // 
            this.btnDraw.Enabled = false;
            this.btnDraw.Font = new System.Drawing.Font("Comic Sans MS", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnDraw.Location = new System.Drawing.Point(852, 126);
            this.btnDraw.Name = "btnDraw";
            this.btnDraw.Size = new System.Drawing.Size(75, 23);
            this.btnDraw.TabIndex = 4;
            this.btnDraw.Text = "Draw";
            this.btnDraw.UseVisualStyleBackColor = true;
            this.btnDraw.Visible = false;
            this.btnDraw.Click += new System.EventHandler(this.btnDraw_Click);
            // 
            // picCard1
            // 
            this.picCard1.BackColor = System.Drawing.Color.Transparent;
            this.picCard1.BackgroundImage = global::prjBLACKJACK.Properties.Resources.card55;
            this.picCard1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.picCard1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.picCard1.Image = global::prjBLACKJACK.Properties.Resources.card55;
            this.picCard1.Location = new System.Drawing.Point(208, 354);
            this.picCard1.Name = "picCard1";
            this.picCard1.Size = new System.Drawing.Size(121, 163);
            this.picCard1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.picCard1.TabIndex = 6;
            this.picCard1.TabStop = false;
            this.picCard1.Visible = false;
            // 
            // lblValueValue
            // 
            this.lblValueValue.BackColor = System.Drawing.Color.Transparent;
            this.lblValueValue.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblValueValue.Font = new System.Drawing.Font("Comic Sans MS", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblValueValue.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.lblValueValue.Location = new System.Drawing.Point(402, 598);
            this.lblValueValue.Name = "lblValueValue";
            this.lblValueValue.Size = new System.Drawing.Size(173, 32);
            this.lblValueValue.TabIndex = 9;
            this.lblValueValue.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.lblValueValue.Visible = false;
            // 
            // txtWager
            // 
            this.txtWager.Enabled = false;
            this.txtWager.Font = new System.Drawing.Font("Comic Sans MS", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtWager.Location = new System.Drawing.Point(842, 302);
            this.txtWager.Name = "txtWager";
            this.txtWager.Size = new System.Drawing.Size(85, 26);
            this.txtWager.TabIndex = 10;
            this.txtWager.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.txtWager.Visible = false;
            this.txtWager.TextChanged += new System.EventHandler(this.txtWager_TextChanged);
            this.txtWager.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtWager_KeyPress);
            // 
            // lblWager
            // 
            this.lblWager.BackColor = System.Drawing.Color.Transparent;
            this.lblWager.Font = new System.Drawing.Font("Comic Sans MS", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblWager.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.lblWager.Location = new System.Drawing.Point(755, 290);
            this.lblWager.Name = "lblWager";
            this.lblWager.Size = new System.Drawing.Size(91, 45);
            this.lblWager.TabIndex = 11;
            this.lblWager.Text = "Wager:";
            this.lblWager.Visible = false;
            // 
            // lblBalance
            // 
            this.lblBalance.BackColor = System.Drawing.Color.Transparent;
            this.lblBalance.Font = new System.Drawing.Font("Comic Sans MS", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblBalance.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.lblBalance.Location = new System.Drawing.Point(755, 254);
            this.lblBalance.Name = "lblBalance";
            this.lblBalance.Size = new System.Drawing.Size(100, 45);
            this.lblBalance.TabIndex = 12;
            this.lblBalance.Text = "Balance:";
            this.lblBalance.Visible = false;
            // 
            // lblBalanceValue
            // 
            this.lblBalanceValue.BackColor = System.Drawing.Color.Transparent;
            this.lblBalanceValue.Font = new System.Drawing.Font("Comic Sans MS", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblBalanceValue.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.lblBalanceValue.Location = new System.Drawing.Point(847, 249);
            this.lblBalanceValue.Name = "lblBalanceValue";
            this.lblBalanceValue.Size = new System.Drawing.Size(90, 41);
            this.lblBalanceValue.TabIndex = 14;
            this.lblBalanceValue.Text = "100";
            this.lblBalanceValue.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.lblBalanceValue.Visible = false;
            // 
            // btnStand
            // 
            this.btnStand.Enabled = false;
            this.btnStand.Font = new System.Drawing.Font("Comic Sans MS", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnStand.Location = new System.Drawing.Point(852, 172);
            this.btnStand.Name = "btnStand";
            this.btnStand.Size = new System.Drawing.Size(75, 23);
            this.btnStand.TabIndex = 15;
            this.btnStand.Text = "Stand";
            this.btnStand.UseVisualStyleBackColor = true;
            this.btnStand.Visible = false;
            this.btnStand.Click += new System.EventHandler(this.btnStand_Click);
            // 
            // btnBet
            // 
            this.btnBet.Enabled = false;
            this.btnBet.Font = new System.Drawing.Font("Comic Sans MS", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnBet.Location = new System.Drawing.Point(852, 334);
            this.btnBet.Name = "btnBet";
            this.btnBet.Size = new System.Drawing.Size(75, 23);
            this.btnBet.TabIndex = 16;
            this.btnBet.Text = "Bet";
            this.btnBet.UseVisualStyleBackColor = true;
            this.btnBet.Visible = false;
            this.btnBet.Click += new System.EventHandler(this.btnBet_Click);
            // 
            // picCard2
            // 
            this.picCard2.BackColor = System.Drawing.Color.Transparent;
            this.picCard2.BackgroundImage = global::prjBLACKJACK.Properties.Resources.card55;
            this.picCard2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.picCard2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.picCard2.Image = global::prjBLACKJACK.Properties.Resources.card55;
            this.picCard2.Location = new System.Drawing.Point(355, 354);
            this.picCard2.Name = "picCard2";
            this.picCard2.Size = new System.Drawing.Size(121, 163);
            this.picCard2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.picCard2.TabIndex = 17;
            this.picCard2.TabStop = false;
            this.picCard2.Visible = false;
            // 
            // picCard3
            // 
            this.picCard3.BackColor = System.Drawing.Color.Transparent;
            this.picCard3.BackgroundImage = global::prjBLACKJACK.Properties.Resources.card55;
            this.picCard3.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.picCard3.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.picCard3.Image = global::prjBLACKJACK.Properties.Resources.card55;
            this.picCard3.Location = new System.Drawing.Point(501, 354);
            this.picCard3.Name = "picCard3";
            this.picCard3.Size = new System.Drawing.Size(121, 163);
            this.picCard3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.picCard3.TabIndex = 18;
            this.picCard3.TabStop = false;
            this.picCard3.Visible = false;
            // 
            // picCard4
            // 
            this.picCard4.BackColor = System.Drawing.Color.Transparent;
            this.picCard4.BackgroundImage = global::prjBLACKJACK.Properties.Resources.card55;
            this.picCard4.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.picCard4.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.picCard4.Image = global::prjBLACKJACK.Properties.Resources.card55;
            this.picCard4.Location = new System.Drawing.Point(642, 354);
            this.picCard4.Name = "picCard4";
            this.picCard4.Size = new System.Drawing.Size(121, 163);
            this.picCard4.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.picCard4.TabIndex = 19;
            this.picCard4.TabStop = false;
            this.picCard4.Visible = false;
            // 
            // picOpponentCard1
            // 
            this.picOpponentCard1.BackColor = System.Drawing.Color.Transparent;
            this.picOpponentCard1.BackgroundImage = global::prjBLACKJACK.Properties.Resources.card55;
            this.picOpponentCard1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.picOpponentCard1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.picOpponentCard1.Image = global::prjBLACKJACK.Properties.Resources.card55;
            this.picOpponentCard1.Location = new System.Drawing.Point(208, 70);
            this.picOpponentCard1.Name = "picOpponentCard1";
            this.picOpponentCard1.Size = new System.Drawing.Size(121, 163);
            this.picOpponentCard1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.picOpponentCard1.TabIndex = 20;
            this.picOpponentCard1.TabStop = false;
            this.picOpponentCard1.Visible = false;
            // 
            // picOpponentCard2
            // 
            this.picOpponentCard2.BackColor = System.Drawing.Color.Transparent;
            this.picOpponentCard2.BackgroundImage = global::prjBLACKJACK.Properties.Resources.card55;
            this.picOpponentCard2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.picOpponentCard2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.picOpponentCard2.Image = global::prjBLACKJACK.Properties.Resources.card55;
            this.picOpponentCard2.Location = new System.Drawing.Point(355, 70);
            this.picOpponentCard2.Name = "picOpponentCard2";
            this.picOpponentCard2.Size = new System.Drawing.Size(121, 163);
            this.picOpponentCard2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.picOpponentCard2.TabIndex = 21;
            this.picOpponentCard2.TabStop = false;
            this.picOpponentCard2.Visible = false;
            // 
            // picOpponentCard3
            // 
            this.picOpponentCard3.BackColor = System.Drawing.Color.Transparent;
            this.picOpponentCard3.BackgroundImage = global::prjBLACKJACK.Properties.Resources.card55;
            this.picOpponentCard3.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.picOpponentCard3.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.picOpponentCard3.Image = global::prjBLACKJACK.Properties.Resources.card55;
            this.picOpponentCard3.Location = new System.Drawing.Point(501, 70);
            this.picOpponentCard3.Name = "picOpponentCard3";
            this.picOpponentCard3.Size = new System.Drawing.Size(121, 163);
            this.picOpponentCard3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.picOpponentCard3.TabIndex = 22;
            this.picOpponentCard3.TabStop = false;
            this.picOpponentCard3.Visible = false;
            // 
            // picOpponentCard4
            // 
            this.picOpponentCard4.BackColor = System.Drawing.Color.Transparent;
            this.picOpponentCard4.BackgroundImage = global::prjBLACKJACK.Properties.Resources.card55;
            this.picOpponentCard4.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.picOpponentCard4.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.picOpponentCard4.Image = global::prjBLACKJACK.Properties.Resources.card55;
            this.picOpponentCard4.Location = new System.Drawing.Point(642, 70);
            this.picOpponentCard4.Name = "picOpponentCard4";
            this.picOpponentCard4.Size = new System.Drawing.Size(121, 163);
            this.picOpponentCard4.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.picOpponentCard4.TabIndex = 23;
            this.picOpponentCard4.TabStop = false;
            this.picOpponentCard4.Visible = false;
            // 
            // btnRestart
            // 
            this.btnRestart.Enabled = false;
            this.btnRestart.Font = new System.Drawing.Font("Comic Sans MS", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnRestart.Location = new System.Drawing.Point(24, 607);
            this.btnRestart.Name = "btnRestart";
            this.btnRestart.Size = new System.Drawing.Size(75, 23);
            this.btnRestart.TabIndex = 24;
            this.btnRestart.Text = "Restart";
            this.btnRestart.UseVisualStyleBackColor = true;
            this.btnRestart.Visible = false;
            this.btnRestart.Click += new System.EventHandler(this.btnRestart_Click);
            // 
            // lblOpponentsValue
            // 
            this.lblOpponentsValue.BackColor = System.Drawing.Color.Transparent;
            this.lblOpponentsValue.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblOpponentsValue.Font = new System.Drawing.Font("Comic Sans MS", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblOpponentsValue.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.lblOpponentsValue.Location = new System.Drawing.Point(402, 35);
            this.lblOpponentsValue.Name = "lblOpponentsValue";
            this.lblOpponentsValue.Size = new System.Drawing.Size(173, 32);
            this.lblOpponentsValue.TabIndex = 25;
            this.lblOpponentsValue.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.lblOpponentsValue.Visible = false;
            // 
            // btnPLAY
            // 
            this.btnPLAY.Font = new System.Drawing.Font("Cooper Black", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnPLAY.ForeColor = System.Drawing.Color.Blue;
            this.btnPLAY.Location = new System.Drawing.Point(852, 60);
            this.btnPLAY.Name = "btnPLAY";
            this.btnPLAY.Size = new System.Drawing.Size(75, 29);
            this.btnPLAY.TabIndex = 26;
            this.btnPLAY.Text = "PLAY";
            this.btnPLAY.UseVisualStyleBackColor = true;
            this.btnPLAY.Click += new System.EventHandler(this.btnPLAY_Click);
            // 
            // btnExit
            // 
            this.btnExit.Font = new System.Drawing.Font("Comic Sans MS", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnExit.Location = new System.Drawing.Point(760, 598);
            this.btnExit.Name = "btnExit";
            this.btnExit.Size = new System.Drawing.Size(75, 23);
            this.btnExit.TabIndex = 27;
            this.btnExit.Text = "Exit";
            this.btnExit.UseVisualStyleBackColor = true;
            this.btnExit.Click += new System.EventHandler(this.btnExit_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = global::prjBLACKJACK.Properties.Resources.tableBackground;
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(939, 653);
            this.Controls.Add(this.btnExit);
            this.Controls.Add(this.btnPLAY);
            this.Controls.Add(this.lblOpponentsValue);
            this.Controls.Add(this.btnRestart);
            this.Controls.Add(this.picOpponentCard4);
            this.Controls.Add(this.picOpponentCard3);
            this.Controls.Add(this.picOpponentCard2);
            this.Controls.Add(this.picOpponentCard1);
            this.Controls.Add(this.picCard4);
            this.Controls.Add(this.picCard3);
            this.Controls.Add(this.picCard2);
            this.Controls.Add(this.btnBet);
            this.Controls.Add(this.btnStand);
            this.Controls.Add(this.lblBalanceValue);
            this.Controls.Add(this.lblBalance);
            this.Controls.Add(this.lblWager);
            this.Controls.Add(this.txtWager);
            this.Controls.Add(this.lblValueValue);
            this.Controls.Add(this.picCard1);
            this.Controls.Add(this.btnDraw);
            this.HelpButton = true;
            this.Name = "Form1";
            this.Text = "Form1";
            
            ((System.ComponentModel.ISupportInitialize)(this.picCard1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picCard2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picCard3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picCard4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picOpponentCard1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picOpponentCard2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picOpponentCard3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picOpponentCard4)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnDraw;
        private System.Windows.Forms.PictureBox picCard1;
        private System.Windows.Forms.Label lblValueValue;
        private System.Windows.Forms.TextBox txtWager;
        private System.Windows.Forms.Label lblWager;
        private System.Windows.Forms.Label lblBalance;
        private System.Windows.Forms.Label lblBalanceValue;
        private System.Windows.Forms.Button btnStand;
        private System.Windows.Forms.Button btnBet;
        private System.Windows.Forms.PictureBox picCard2;
        private System.Windows.Forms.PictureBox picCard3;
        private System.Windows.Forms.PictureBox picCard4;
        private System.Windows.Forms.PictureBox picOpponentCard1;
        private System.Windows.Forms.PictureBox picOpponentCard2;
        private System.Windows.Forms.PictureBox picOpponentCard3;
        private System.Windows.Forms.PictureBox picOpponentCard4;
        private System.Windows.Forms.Button btnRestart;
        private System.Windows.Forms.Label lblOpponentsValue;
        private System.Windows.Forms.Button btnPLAY;
        private System.Windows.Forms.Button btnExit;
    }
}

