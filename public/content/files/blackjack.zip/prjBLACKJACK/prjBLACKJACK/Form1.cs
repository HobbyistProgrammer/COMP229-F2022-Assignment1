﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace prjBLACKJACK
{
    public partial class Form1 : Form
    {
        /*********************************
         * ************MY VARIABLES*******
         * *******************************/
        Random r = new Random();
        int randomCardNumber = 0;
        int CardNumber1 = 0;
        int CardNumber2 = 0;
        int CardNumber3 = 0;
        int CardNumber4 = 0;
        int CardNumber5 = 0;
        int CardNumber6 = 0;
        int CardNumber7 = 0;
        int CardNumber8 = 0;
        string cardFileName1 = "";
        string cardFileName2 = "";
        string cardFileName3 = "";
        string cardFileName4 = "";
        string cardFileName5 = "";
        string cardFileName6 = "";
        string cardFileName7 = "";
        string cardFileName8 = "";
        int actualCardValue1 = 0;
        int wager = 0;
        int balance = 0;
        int HitCard = 0;
        int totalOpponentCardValue = 0;
        int totalCardValue = 0;
        int actualCardValue2 = 0;
        int actualCardValue3 = 0;
        int actualCardValue4 = 0;
        int actualOpponentCardValue1 = 0;
        int actualOpponentCardValue2 = 0;
        int actualOpponentCardValue3 = 0;
        int actualOpponentCardValue4 = 0;
        int opponentStayVariable = 0;

        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void btnDraw_Click(object sender, EventArgs e)
        {
                 
               
            if (HitCard == 0) 
            {
                //////////////////////////////////////////Get your 3rd card//////////////////////////////////////////////////////////////////////
                CardNumber3 = r.Next(1, 53);
                cardFileName3 = "cards/card" + CardNumber3 + ".jpg";
                picCard3.Image = Image.FromFile(cardFileName3);
                actualCardValue3 = CardNumber3 % 13;
                if (actualCardValue3 == 0 || actualCardValue3 == 11 || actualCardValue3 == 12)
                {
                    actualCardValue3 = 10;
                }
                totalCardValue = actualCardValue3 + actualCardValue2 + actualCardValue1;
                lblValueValue.Text = totalCardValue + "";
                if (actualCardValue1 + actualCardValue2 + actualCardValue3 > 21)
                {
                    MessageBox.Show("HA GIT GUD. YOU LOST");
                    btnDraw.Enabled = false;
                    btnStand.Enabled = false;
                    btnRestart.Enabled = true;
                }
                if (actualCardValue1 + actualCardValue2 + actualCardValue3 == 21)
                {
                    MessageBox.Show("Oh you won...");
                    btnDraw.Enabled = false;
                    btnStand.Enabled = false;
                    btnRestart.Enabled = true;
                }
                HitCard = 1;
               
            }


            ///////////////////////////////////////////////////////////////Set up for Card 4//////////////////////////////////////////////////////
            else if (HitCard == 1)
            {
             
                CardNumber4 = r.Next(1, 53);
                cardFileName4 = "cards/card" + CardNumber4 + ".jpg";
                picCard4.Image = Image.FromFile(cardFileName4);
                actualCardValue4 = CardNumber4 % 13;
                if (actualCardValue4 == 0 || actualCardValue4 == 11 || actualCardValue4 == 12)
                {
                    actualCardValue4 = 10;
                }
                totalCardValue = actualCardValue4 + actualCardValue3 + actualCardValue2 + actualCardValue1;
                lblValueValue.Text = totalCardValue + "";

                if (actualCardValue1 + actualCardValue2 + actualCardValue3 + actualCardValue4 > 21)
                {
                    MessageBox.Show("HA GIT GUD. YOU LOST");
                    btnDraw.Enabled = false;
                    btnStand.Enabled = false;
                    btnRestart.Enabled = true;
                }
                if (actualCardValue1 + actualCardValue2 + actualCardValue3 + actualCardValue4 == 21)
                {
                    MessageBox.Show("Oh, You won...");
                    btnDraw.Enabled = false;
                    btnStand.Enabled = false;
                    btnRestart.Enabled = true;
                }
                HitCard = 3;
                
            }
            


        }

       
        private void btnBet_Click_1(object sender, EventArgs e)
        {
            

            
        }

        private void txtWager_TextChanged(object sender, EventArgs e)
        {
            btnBet.Enabled = true;
            
        }

        private void btnRestart_Click(object sender, EventArgs e)
        {
            picCard1.Image = null;
            picCard2.Image = null;
            picCard3.Image = null;
            picCard4.Image = null;
            picOpponentCard1.Image = null;
            picOpponentCard2.Image = null;
            picOpponentCard3.Image = null;
            picOpponentCard4.Image = null;
            picCard1.Visible = true;
            picCard2.Visible = true;
            picCard3.Visible = true;
            picCard4.Visible = true;
            picOpponentCard1.Visible = true;
            btnDraw.Enabled = false;
            btnStand.Enabled = false;
            btnBet.Enabled = false;
            txtWager.Enabled = false;
            btnPLAY.Enabled = true;
            lblOpponentsValue.Visible = true;
            lblValueValue.Visible = true;
            btnBet.Visible = false;
            btnDraw.Visible = true;
            btnStand.Visible = true;
            btnPLAY.Visible = true;
            lblBalance.Visible = true;
            lblBalanceValue.Visible = true;
            txtWager.Visible = true;
            lblWager.Visible = true;
            btnRestart.Visible = true;
            HitCard = 0;
            lblValueValue.Text = null;
            lblOpponentsValue.Text = null;
            txtWager.Text = null;
            btnRestart.Enabled = false;
            btnStand.Enabled = false;
            if (balance == 0)
            {
                MessageBox.Show("MUAHAHAHAHAHAH! Better luck next time.. >:)");
                    this.Close();
            }

        }

        private void btnStand_Click(object sender, EventArgs e)
        {
            if (totalOpponentCardValue <= 16)
            {
                picOpponentCard2.Visible = true;
                totalOpponentCardValue = totalOpponentCardValue + actualOpponentCardValue1;
                opponentStayVariable = 1;   
            }
            if (opponentStayVariable == 1 && totalOpponentCardValue <= 16)
            {
                picOpponentCard3.Visible = true;
                totalOpponentCardValue = totalOpponentCardValue + actualOpponentCardValue2;
                opponentStayVariable = 2;   
            }
            if (opponentStayVariable == 2 && totalOpponentCardValue <= 16)
            {
                picOpponentCard3.Visible = true;
                totalOpponentCardValue = totalOpponentCardValue + actualOpponentCardValue3;
                opponentStayVariable = 3;
            }
            if (opponentStayVariable == 3 && totalOpponentCardValue <= 16)
            {
                picOpponentCard3.Visible = true;
                totalOpponentCardValue = totalOpponentCardValue + actualOpponentCardValue4;
                opponentStayVariable = 4;
            }
            lblOpponentsValue.Text = totalOpponentCardValue + "";
            /////////////////////////////////////////////////////////////////////////////
            /////////////////////////////////////////////////////////////////////////////
            //WIN STATEMENTS(THE PART THE SHOWS HOW TO WIN AND HOW TO LOSE)///////////////
            //////////////////////////////////////////////////////////////////////////////
            /////////////////////////////////////////////////////////////////////////////
            //When both values are under 21 but the user's value is greater than the Opponent
            if (totalCardValue <= 21 && totalOpponentCardValue <= 21 && totalCardValue > totalOpponentCardValue)
            {
                MessageBox.Show("You win!!!!");
                balance = balance + wager + wager;
                lblBalanceValue.Text = balance + "";
                btnDraw.Enabled = false;
                btnStand.Enabled = false;
                btnRestart.Enabled = true;
                
            }

            //When both values are under 21 but the user's value is less than the Opponent
            else if (totalCardValue <= 21 && totalOpponentCardValue <= 21 && totalOpponentCardValue > totalCardValue)
            {
                MessageBox.Show("Hehe, noob, you lost");
                btnDraw.Enabled = false;
                btnStand.Enabled = false;
                btnRestart.Enabled = true;
            }

            //When the user's value goes over 21 and the opponent's value doesnt
            else if (totalCardValue > 21 && totalOpponentCardValue <= 21)
            {
                MessageBox.Show("Ya went bust kid... ya went over 21");
                btnDraw.Enabled = false;
                btnStand.Enabled = false;
                btnRestart.Enabled = true;
            }

            //When the opponent's value goes over 21 and the user's value doesnt
            else if (totalCardValue <= 21 && totalOpponentCardValue > 21)
            {
                MessageBox.Show("YOU WON DUDE. Luckily, the dealer went over 21");
                balance = balance + wager + wager;
                lblBalanceValue.Text = balance + "";
                btnDraw.Enabled = false;
                btnStand.Enabled = false;
                btnRestart.Enabled = true;
            }

            //When the user's value and the opponent's value are over 21 but the user's value is less than the opponent
            else if (totalCardValue > 21 && totalOpponentCardValue > 21 && totalCardValue < totalOpponentCardValue)
            {
                MessageBox.Show("YOU WON DUDE. Luckily, the dealer went over 21");
                balance = balance + wager+ wager;
                lblBalanceValue.Text = balance + "";
                btnDraw.Enabled = false;
                btnStand.Enabled = false;
                btnRestart.Enabled = true;
            }
            else if (totalCardValue == totalOpponentCardValue)
            {
                MessageBox.Show("YOU WON DUDE. (Its actually a tie, but I'll give you a victory because im nice");
                balance = balance + wager + wager;
                lblBalanceValue.Text = balance + "";
                btnDraw.Enabled = false;
                btnStand.Enabled = false;
                btnRestart.Enabled = true;
            }

            //If anything else happens
            else
            {
                MessageBox.Show("You just SUCK");
                btnDraw.Enabled = false;
                btnStand.Enabled = false;
                btnRestart.Enabled = true;
            }
        }

        private void btnPLAY_Click(object sender, EventArgs e)
        {
            picCard1.Visible = true;
            picCard2.Visible = true;
            picCard3.Visible = true;
            picCard4.Visible = true;
            picOpponentCard1.Visible = true;
            btnDraw.Enabled = false;
            btnStand.Enabled = false;
            btnBet.Enabled = false;
            txtWager.Enabled = true;
            btnPLAY.Enabled = false;
            lblOpponentsValue.Visible = true;
            lblValueValue.Visible = true;
            btnBet.Visible = true;
            btnDraw.Visible = true;
            btnStand.Visible = true;
            btnPLAY.Visible = false;
            lblBalance.Visible=true;
            lblBalanceValue.Visible = true;
            txtWager.Visible = true;
            lblWager.Visible = true;
            btnRestart.Visible = true;
            HitCard = 0;
            picOpponentCard2.Image = null;
            picOpponentCard3.Image = null;
            picOpponentCard4.Image = null;

            //Your 1st Card
            //Get a random card number
            CardNumber1 = r.Next(1, 53);

            //Create filename for card number
            cardFileName1 = "cards/card" + CardNumber1 + ".jpg";

            //Show the card image
            picCard1.Image = Image.FromFile(cardFileName1);

            //Find the real value of the card
            actualCardValue1 = CardNumber1 % 13;
            if (actualCardValue1 == 0 || actualCardValue1 == 11 || actualCardValue1 == 12)
            {
                actualCardValue1 = 10;
            }

            //Show true value of card in Value label
            lblValueValue.Text = actualCardValue1 + "";


            //Get your 2nd Card
            CardNumber2 = r.Next(1, 53);
            cardFileName2 = "cards/card" + CardNumber2 + ".jpg";
            picCard2.Image = Image.FromFile(cardFileName2);
            actualCardValue2 = CardNumber2 % 13;
            if (actualCardValue2 == 0 || actualCardValue2 == 11 || actualCardValue2 == 12)
            {
                actualCardValue2 = 10;
            }
            lblValueValue.Text = actualCardValue2 + actualCardValue1 + "";
            if (actualCardValue1 + actualCardValue2 > 21)
            {
                MessageBox.Show("HA GIT GUD. YOU LOST");
                btnDraw.Enabled = false;
                btnStand.Enabled = false;
            }
            if (actualCardValue1 + actualCardValue2 == 21)
            {
                MessageBox.Show("Oh You won...");
                btnDraw.Enabled = false;
                btnStand.Enabled = false;
            }


            //Find Opponents Card 1   
            CardNumber5 = r.Next(1, 53);
            cardFileName5 = "cards/card" + CardNumber5 + ".jpg";
            picOpponentCard1.Image = Image.FromFile(cardFileName5);
            actualOpponentCardValue1 = CardNumber5 % 13;
            if (actualOpponentCardValue1 == 0 || actualOpponentCardValue1 == 11 || actualOpponentCardValue1 == 12)
            {
                actualOpponentCardValue1 = 10;
            }
            totalOpponentCardValue = actualOpponentCardValue1;
            lblOpponentsValue.Text = totalOpponentCardValue + "";



            //Find Opponents  Card 2
            CardNumber6 = r.Next(1, 53);
            cardFileName6 = "cards/card" + CardNumber6 + ".jpg";
            picOpponentCard2.Image = Image.FromFile(cardFileName6);
            actualOpponentCardValue2 = CardNumber6 % 13;
            if (actualOpponentCardValue2 == 0 || actualOpponentCardValue2 == 11 || actualOpponentCardValue2 == 12)
            {
                actualOpponentCardValue2 = 10;
            }


            //Find Oppenents Card 3
            CardNumber7 = r.Next(1, 53);
            cardFileName7 = "cards/card" + CardNumber7 + ".jpg";
            picOpponentCard3.Image = Image.FromFile(cardFileName7);
            actualOpponentCardValue3 = CardNumber7 % 13;
            if (actualOpponentCardValue3 == 0 || actualOpponentCardValue3 == 11 || actualOpponentCardValue3 == 12)
            {
                actualOpponentCardValue3 = 10;
            }
            
            //Find Opponents Card 4
            CardNumber8 = r.Next(1, 53);
            cardFileName8 = "cards/card" + CardNumber8 + ".jpg";
            picOpponentCard4.Image = Image.FromFile(cardFileName8);
            actualOpponentCardValue4 = CardNumber8 % 13;
            if (actualOpponentCardValue4 == 0 || actualOpponentCardValue4 == 11 || actualOpponentCardValue4 == 12)
            {
                actualOpponentCardValue4 = 10;
            }
            
        }

        private void btnBet_Click(object sender, EventArgs e)
        {
            txtWager.Enabled = false;
            btnDraw.Enabled = true;
            wager = Convert.ToInt16(txtWager.Text);
            balance = Convert.ToInt16(lblBalanceValue.Text);
            //balance = balance - wager;
            //lblBalanceValue.Text = balance + "";
            btnBet.Enabled = false;
            btnStand.Enabled = true;
            if (wager > balance)
            {
                txtWager.Text = 0 + "";
                balance = balance + wager;
                MessageBox.Show("Not Enough Cash to make bet");
                lblBalanceValue.Text = balance + "";
                btnBet.Enabled = true;
                btnDraw.Enabled = false;
                btnStand.Enabled = false;
                txtWager.Enabled = true;
            }
            if (wager < 1)
            {
                txtWager.Text = 0 + "";
                balance = balance + wager;
                MessageBox.Show("The minimum amount for a bet is 1");
                lblBalanceValue.Text = balance + "";
                btnBet.Enabled = true;
                btnDraw.Enabled = false;
                btnStand.Enabled = false;
                txtWager.Enabled = true;
            }
            balance = balance - wager;
            lblBalanceValue.Text = balance + "";
        }

        private void txtWager_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar) &&
       (e.KeyChar != '.'))
            {
                e.Handled = true;
            }

            // only allow one decimal point
            if ((e.KeyChar == '.') && ((sender as TextBox).Text.IndexOf('.') > -1))
            {
                e.Handled = true;
            }
        }

        private void btnExit_Click(object sender, EventArgs e)
        {

        }
    }
}